---
title: "وبلاگ"
---

<div style="text-align: center; margin-top: 1em;">
{{< hextra/hero-badge link="index.xml" >}}
  <span>خوراک RSS</span>
  {{< icon name="rss" attributes="height=14" >}}
{{< /hextra/hero-badge >}}
</div>
