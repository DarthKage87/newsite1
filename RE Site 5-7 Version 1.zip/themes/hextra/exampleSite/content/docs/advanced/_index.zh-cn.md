---
linkTitle: 高级
title: 高级主题
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

本节涵盖了一些主题的高级内容。

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="多语言" icon="translate" >}}
  {{< card link="customization" title="自定义" icon="pencil" >}}
  {{< card link="comments" title="评论系统" icon="chat-alt" >}}
{{< /cards >}}