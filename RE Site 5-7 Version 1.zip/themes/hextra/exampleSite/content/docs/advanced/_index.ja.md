---
linkTitle: 上級者向け
title: 上級者向けトピック
prev: /docs/guide/shortcodes/tabs
next: /docs/advanced/multi-language
---

このセクションでは、テーマの上級者向けトピックをカバーします。

<!--more-->

{{< cards >}}
  {{< card link="multi-language" title="多言語対応" icon="translate" >}}
  {{< card link="customization" title="カスタマイズ" icon="pencil" >}}
  {{< card link="comments" title="コメントシステム" icon="chat-alt" >}}
{{< /cards >}}